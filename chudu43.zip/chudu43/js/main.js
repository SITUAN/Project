$( document ).ready(function() {
    $('#slider-top').owlCarousel({
        stagePadding: 0,
        items: 1,
        loop:true,
        margin:0,
        singleItem:true,
        autoplay: true,
        nav:true,
        dots:false,
        navText: ["<i class='fa fa-chevron-left' aria-hidden='true'></i>","<i class='fa fa-chevron-right' aria-hidden='true'></i>"]
    });
});

$(function () {
  $('[data-toggle="offcanvas"]').on('click', function () {
    $('.offcanvas-collapse').toggleClass('open')
  })
})
// setTimeout(function(){
//     $('.phone-contact #phone-animate').removeClass('animate');

// }, 500); 

setInterval(function(){ 
    $('.phone-contact #phone-animate').removeClass('animate');
    $('.phone-contact #phone-animate').removeClass('seven');
    $('.phone-contact #phone-animate').removeClass('four');
    setTimeout(function(){
        $('.phone-contact #phone-animate').addClass('animate');
        $('.phone-contact #phone-animate').addClass('four');
    }, 1000);
}, 6000);

function convertDate_ddmmyyyy(date) {
    return moment(date).format("DD/MM/YYYY")
}
var datein = $('#dtpTimeIn input').val();
if(datein){} else {
    $('#dtpTimeIn input, #dtpTimeOut input').val(convertDate_ddmmyyyy(new Date()));
    var myDate = new Date()
    myDate.setDate(myDate.getDate() + 1);
    $('#dtpTimeOut input').val(convertDate_ddmmyyyy(myDate));
}

$('#dtpTimeIn, #dtpTimeOut').datepicker({
    'language': 'vi',
    'autoclose': true,
    'format': 'dd/mm/yyyy',
    'todayHighlight': true,
    'showOnFocus': true,
    'defaultDate': new Date(),
    'startDate': '+0d',
    'templates':{
        'leftArrow': '<i class="fa fa-angle-double-left"></i>',
        'rightArrow': '<i class="fa fa-angle-double-right"></i>'
    }
});
var timeout = null;
function call_ajax(post_type) {
    if(post_type === 'khach-san'){
        var data = $('#tenks').val();
    } else {
        var data = $('#tentour').val();
    }
    
    $.ajax({
        type: 'POST',
        async: true,
        url: 'https://www.chudu43.com/wp-admin/admin-ajax.php',
        data: {
            'action' : 'Post_filters', 
            'data': data,
            'post_type': post_type
        },
        beforeSend: function () {
            $('.load-img').show();
        },
        success: function (data) {
            $('.load-img').hide();
            if(post_type == 'khach-san'){
                $('#tenks').next('.hotel-result').children('ul').html(data);
            } else {
                $('#tentour').next('.hotel-result').children('ul').html(data);
            }
        }
    });
}
$("#tenks").keyup(function(){
    $(this).next('.hotel-result').show();
    $('.load-img').show();
    clearTimeout(timeout);
    timeout = setTimeout(function ()
    {
       call_ajax('khach-san');
    }, 500);
});
$("#tentour").keyup(function(){
    $(this).next('.hotel-result').show();
    $('.load-img').show();
    clearTimeout(timeout);
    timeout = setTimeout(function ()
    {
       call_ajax('tour');
    }, 500);
});
$('.span-close').click(function(event) {
    $('.hotel-result').hide();
});
$(document).ready(function() {
    $('.view-detail-room').click(function(event) {
        event.preventDefault();
        var id = $(this).data('id');
        $('#'+id).slideToggle(300);
    });
    $('.chon-phong').change(function(event) {
        event.preventDefault();
        var price = $(this).data('price');
        var id = $(this).data('id');
        var value = $(this).val();
        $('#'+id).html(price*value);
        $('#'+id).text(function () { 
            var str = $(this).html() + ''; 
            x = str.split(','); 
            x1 = x[0]; x2 = x.length > 1 ? ',' + x[1] : ''; 
            var rgx = /(\d+)(\d{3})/; 
            while (rgx.test(x1)) { 
                x1 = x1.replace(rgx, '$1' + '.' + '$2'); 
            } 
            $(this).html(x1 + x2); 
        });
    });
    $('.form-submit').submit(function(event) {
        var selct = $(this).serializeArray();
        if(selct['2'].value == 0){
            event.preventDefault();
            alert('Vui lòng chọn số phòng!');
        }
    });
    $('.nam_hotel').val($('.info-book-hotelk h2').text());
    $('.nam_room').val($('.r_name').text());
    $('.num_room').val($('.r_num').text());
    $('.datein').val($('.d_in').text());
    $('.dateout').val($('.d_out').text());
    $('.price').val($('.t_price').text());
});